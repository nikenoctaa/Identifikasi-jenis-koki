function varargout = Identifikasi_ikan_koki(varargin)
% IDENTIFIKASI_IKAN_KOKI MATLAB code for Identifikasi_ikan_koki.fig
%      IDENTIFIKASI_IKAN_KOKI, by itself, creates a new IDENTIFIKASI_IKAN_KOKI or raises the existing
%      singleton*.
%
%      H = IDENTIFIKASI_IKAN_KOKI returns the handle to a new IDENTIFIKASI_IKAN_KOKI or the handle to
%      the existing singleton*.
%
%      IDENTIFIKASI_IKAN_KOKI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in IDENTIFIKASI_IKAN_KOKI.M with the given input arguments.
%
%      IDENTIFIKASI_IKAN_KOKI('Property','Value',...) creates a new IDENTIFIKASI_IKAN_KOKI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Identifikasi_ikan_koki_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Identifikasi_ikan_koki_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Identifikasi_ikan_koki

% Last Modified by GUIDE v2.5 06-Dec-2019 23:05:37

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Identifikasi_ikan_koki_OpeningFcn, ...
                   'gui_OutputFcn',  @Identifikasi_ikan_koki_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Identifikasi_ikan_koki is made visible.
function Identifikasi_ikan_koki_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Identifikasi_ikan_koki (see VARARGIN)

% Choose default command line output for Identifikasi_ikan_koki
handles.output = hObject;

% Update handles structure
warning('off','all')
guidata(hObject, handles);
movegui(hObject,'center');

% UIWAIT makes Identifikasi_ikan_koki wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Identifikasi_ikan_koki_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% menampilkan menu browse file
[file, path] = uigetfile('*.jpg');

% jika ada file yang dipilih maka menjalankan perintah di bawahnya
if ~isequal(file,0)
    % membaca file citra yang dipilih
    Img = imread(fullfile(path, file));
    % menampilkan citra pada axes
    axes(handles.axes1)
    imshow(Img)
    % menyimpan variabel Img pada lokasi handles (lokasi penyimpanan MATLAB
    % agar dapat dipanggil pada pushbutton yang lain)
    handles.Img = Img;
    guidata(hObject, handles)
    
    % mereset button2
    set(handles.pushbutton2,'Enable','on')
    set(handles.pushbutton3,'Enable','off')
    set(handles.edit1,'String',[])
    set(handles.text2,'String',[])
    set(handles.uitable1,'Data',[])
    axes(handles.axes2)
    cla reset
    set(gca,'XTick',[])
    set(gca,'YTick',[])
else
    return
end

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% memanggil variabel Img yang ada pada lokasi handles
Img = handles.Img;
% mengkonversi citra rgb menjadi grayscale
Img = rgb2gray(Img);
% menampilkan citra grayscale pada axes
axes(handles.axes2)
imshow(Img)
% melakukan ekstraksi ciri orde satu pada citra grayscale
H = imhist(Img)';
H = H/sum(H);
I = [0:255];
CiriMEAN = I*H';
CiriENT = -H*log2(H+eps)';
CiriVAR = (I-CiriMEAN).^2*H';
CiriSKEW = (I-CiriMEAN).^3*H'/CiriVAR^1.5;
CiriKURT = (I-CiriMEAN).^4*H'/CiriVAR^2-3;
data_uji = [CiriMEAN,CiriENT,CiriVAR,CiriSKEW,CiriKURT];
% menampilkan hasil ekstraksi ciri orde satupada tabel
data_tabel = cell(5,2);
data_tabel{1,1} = 'Mean';
data_tabel{2,1} = 'Entropy';
data_tabel{3,1} = 'Variance';
data_tabel{4,1} = 'Skewness';
data_tabel{5,1} = 'Kurtosis';
data_tabel{1,2} = num2str(CiriMEAN);
data_tabel{2,2} = num2str(CiriENT);
data_tabel{3,2} = num2str(CiriVAR);
data_tabel{4,2} = num2str(CiriSKEW);
data_tabel{5,2} = num2str(CiriKURT);
set(handles.text2,'String','Citra Asli')
set(handles.uitable1,'Data',data_tabel,'RowName',1:5)

% mereset button2
set(handles.pushbutton3,'Enable','on')
set(handles.edit1,'String',[])
% menyimpan variabel data_uji pada lokasi handles
handles.data_uji = data_uji;
guidata(hObject, handles)


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% memanggil variabel data_uji yang ada pada lokasi handles
data_uji = handles.data_uji;

% load data_latih dan target_latih hasil pelatihan
load data_latih
load target_latih

% pengujian menggunakan algoritma multisvm
output = multisvm(data_latih,target_latih,data_uji);

% mengubah nilai keluaran menjadi kelas keluaran
switch output
    case 1
        jenis_koki = 'Ikan Koki Oranda';
    case 2
        jenis_koki = 'Ikan Koki Ranchu';
    case 3
        jenis_koki = 'Ikan Koki Bubble-Eyes';
    case 4
        jenis_koki = 'Ikan Koki Panda-moor'
    case 5
        jenis_koki = 'Ikan Koki Butterfly Tail'
    case 6
        jenis_koki = 'Ikan Koki Black-moor'
    otherwise
        jenis_koki = 'Unknown';
end

% menampilkan hasil identifikasi jenis bunga pada edit text
set(handles.edit1,'String',jenis_koki)

% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% mereset button2
set(handles.pushbutton2,'Enable','off')
set(handles.pushbutton3,'Enable','off')
set(handles.edit1,'String',[])
set(handles.text2,'String',[])
set(handles.uitable1,'Data',[])
axes(handles.axes1)
cla reset
set(gca,'XTick',[])
set(gca,'YTick',[])
axes(handles.axes2)
cla reset
set(gca,'XTick',[])
set(gca,'YTick',[])
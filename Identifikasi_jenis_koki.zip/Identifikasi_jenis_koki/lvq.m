clc; clear; close all;

% membaca file citra dalam folder
image_folder = 'data latih'; %folder data latih
filenames = dir(fullfile(image_folder, '*.jpg'));
jumlah_data = numel(filenames);

total_latih = [];
kelas = 1;
for k = 1:jumlah_data
    full_name= fullfile(image_folder, filenames(k).name);
    Img = imread(full_name);
    
    Img = imresize(Img,[150 150]);
    gray = rgb2gray(Img);
    
    tepi = edge(gray,'canny');
    
    gabungan = [gray double(tepi)];
    
    gabung_pca = pca(double(gabungan));
    
    fitur = transpose(gabung_pca);
    fitur = fitur(:).';
    
    total_latih = cat(1,total_latih,[fitur kelas]); %cat = concat 1 kebawah, 2 kekanan, 3 dimensi
    if mod(k,5)==0 %ada belapa data training per subjectnya (ini nanti diganti 7 soalnya data latihnya tiap image ada 7)
        kelas = kelas+1;
    end
end


% membaca file citra dalam folder
image_folder = 'data uji'; %folder data uji
filenames = dir(fullfile(image_folder, '*.jpg'));
jumlah_data = numel(filenames);

total_uji = [];
kelas = 1;
for k = 1:jumlah_data
    full_name= fullfile(image_folder, filenames(k).name);
    Img = imread(full_name);
    
    Img = imresize(Img,[150 150]);
    gray = rgb2gray(Img);
    
    tepi = edge(gray,'canny');
    
    gabungan = [gray double(tepi)];
    
    gabung_pca = pca(double(gabungan));
    
    fitur = transpose(gabung_pca);
    fitur = fitur(:).';
    
    total_uji = cat(1,total_uji,[fitur kelas]); %cat = concat 1 kebawah, 2 kekanan, 3 dimensi
    if mod(k,2)==0 %ada belapa data training per subjectnya (2 nanti diganti 3 kan tiap image ada 3 data uji)
        kelas = kelas+1;
    end
end

net = lvqnet(10);
net.trainParam.epochs = 50; %iterasi
net = train(net,total_latih(:,1:end-1).',total_latih(:,end).');

hasil = sim(net,total_uji(:,1:end-1).');

akurasi = (sum(hasil==total_uji(:,end).')/length(hasil))*100;
disp(akurasi);



